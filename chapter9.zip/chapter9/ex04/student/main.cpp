#include <iostream> 
#include <fstream>
#include <iomanip>
#include <cstring>
#include <cctype>
using namespace std;



struct menuItemType
{
    string menuItem;
    double menuPrice;
};

void showMenu(menuItemType xmenu[8]);
void getData(int xmenuL[], menuItemType zmenu[8], int xcnt);
void printCheck(int ycnt, menuItemType xmenuList[]);
int main(){
   
   menuItemType menu[8]; 
   showMenu(menu);
   int size = 8, menuL[size], choice,cnt = 0;
   char  ans, ans2;
   
   cout<<"Do you want to make selection Y/y (Yes), N/n (No): ";
   cin>>ans2;
   ans2 = toupper(ans2);
   

   if(ans2 == 'Y'){
        do{
            cout<<"Enter item number: ";
            cin >> choice;
    
            switch(choice){
                case 1:
                    menuL[cnt] = choice;
                case 2:
                    menuL[cnt] = choice;
                case 3:
                    menuL[cnt] = choice;
                case 4:
                    menuL[cnt] = choice;
                case 5:
                    menuL[cnt] = choice;
                case 6:
                    menuL[cnt] = choice;
                case 7:
                    menuL[cnt] = choice;
                case 8:
                    menuL[cnt] = choice;
            }

            cnt++;
            cout<<"Select another item Y/y (Yes), N/n (No): ";
            cin >> ans;
            ans = toupper(ans);

        }while(ans == 'Y');
   } 

   getData(menuL, menu, cnt);




    return 0;
}
///////////////////////////////////////////

void showMenu(menuItemType xmenu[8]){

    int count = 0, i = 0;
    string food;

    cout<<"Welcome to Johnny's Resturant"<<endl
        <<"----Today's Menu----"<<endl;
    ifstream File;
    File.open("Ch9_Ex4Data.txt");

    while(getline(File, food)) {
        if(count%2==1 && count > 0){
            xmenu[i].menuPrice = stod(food);
            i++;
        }

        else{
            xmenu[i].menuItem = food;
        } 
        count++;
    }

    File.close();

    for(int i = 0; i<8; i++){
        cout<<i + 1<<": "<<xmenu[i].menuItem<<setw(7)<<"$"<<xmenu[i].menuPrice<<endl;
    }
    cout<<endl<<"You can make up to 8 single order selections "<<endl;
    
}
////////////////////////////////////////////

void getData(int xmenuL[], menuItemType zmenu[8], int xcnt){

    menuItemType menuList[xcnt];
    int navi;
    for(int i = 0; i < xcnt; i++){
        navi = xmenuL[i];
        menuList[i].menuItem = zmenu[navi-1].menuItem;
        menuList[i].menuPrice = zmenu[navi-1].menuPrice;
    }
    printCheck(xcnt, menuList);

}
////////////////////////////////////////////

void printCheck(int ycnt, menuItemType xmenuList[]){

    double total = 0, tax;
    
    cout<<endl<<"Welcome to Johnny's Resturant"<<endl;
    for(int i = 0 ; i < ycnt; i++){
        total = total + xmenuList[i].menuPrice;
        cout<<xmenuList[i].menuItem<<setw(7)<<"$"<<xmenuList[i].menuPrice<<endl;
    }
    tax = (total * 0.05);
    if (tax > 0.26){
        tax = 0.26;
    }
    total = total + tax;
    cout<<"Tax"<<setw(7)<<"$"<<fixed<<setprecision(2)<<tax<<endl;
    cout<<"Amount Due"<<setw(7)<<"$"<<fixed<<setprecision(2)<<total<<endl;
}