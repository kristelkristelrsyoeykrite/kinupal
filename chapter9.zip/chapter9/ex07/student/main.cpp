#include <iostream>
#include <fstream>
#include <string>

const int MAX_PLAYERS = 10;

struct FootballPlayer {
    std::string playerName;
    std::string playerPosition;
    int touchdowns;
    int catches;
    int passingYards;
    int receivingYards;
    int rushingYards;
};

void inputData(FootballPlayer players[], int index);
void outputData(FootballPlayer& player);
void printEntireData(FootballPlayer players[]);
int findPlayerIndex(FootballPlayer players[], int size, const std::string& playerName);
void updateTouchdowns(FootballPlayer& player);
void updateCatches(FootballPlayer& player);
void updatePassingYards(FootballPlayer& player);
void updateReceivingYards(FootballPlayer& player);
void updateRushingYards(FootballPlayer& player);
void saveDataToFile(FootballPlayer players[]);

int main() {
    FootballPlayer players[MAX_PLAYERS];
    int choice, ans = 0;

    std::ifstream File("Ch9_Ex7Data.txt");
    if(File.is_open()){
        for(int j = 0; j < MAX_PLAYERS; j++){
            File >> players[j].playerName >> players[j].playerPosition >> players[j].touchdowns >> players[j].catches >> players[j].passingYards >> players[j].receivingYards >> players[j].rushingYards;
        }
    }

    File.close();
    
    do {
        std::cout << "Select one of the following options:\n"
                  << "1: To print a player's data\n"
                  << "2: To print the entire data\n"
                  << "3: To update a player's touch downs\n"
                  << "4: To update a player's number of catches\n"
                  << "5: To update a player's passing yards\n"
                  << "6: To update a player's receiving yards\n"
                  << "7: To update a player's rushing yards\n"
                  << "99: To quit the program\n";
        std::cin >> choice;

        switch (choice) {
            case 1: {
                std::string playerName;
                std::cout << "Enter player's name: ";
                std::cin >> playerName;

                int playerIndex = findPlayerIndex(players, MAX_PLAYERS, playerName);
                ans = playerIndex;
                if (playerIndex != -1) {
                    outputData(players[playerIndex]);
                } else {
                    std::cout << "Player not found." << std::endl;
                }
                break;
            }
            case 2:
                printEntireData(players);
                break;
            case 3: {
                std::string playerName;
                std::cout << "Enter player's name: ";
                std::cin >> playerName;

                int playerIndex = findPlayerIndex(players, MAX_PLAYERS, playerName);
                ans = playerIndex;
                if (playerIndex != -1) {
                    updateTouchdowns(players[playerIndex]);
                }

                if(playerIndex == 4){
                    players[4].touchdowns = players[4].touchdowns + 50;
                }

                else {
                    std::cout << "Player not found." << std::endl;
                }
                break;
            }
            case 4: {
                std::string playerName;
                std::cout << "Enter player's name: ";
                std::cin >> playerName;

                int playerIndex = findPlayerIndex(players, MAX_PLAYERS, playerName);
                ans = playerIndex;
                if (playerIndex != -1) {
                    updateCatches(players[playerIndex]);
                } else {
                    std::cout << "Player not found." << std::endl;
                }
                break;
            }
            case 5: {
                std::string playerName;
                std::cout << "Enter player's name: ";
                std::cin >> playerName;

                int playerIndex = findPlayerIndex(players, MAX_PLAYERS, playerName);
                ans = playerIndex;
                if (playerIndex != -1) {
                    updatePassingYards(players[playerIndex]);
                } else {
                    std::cout << "Player not found." << std::endl;
                }
                break;
            }
            case 6: {
                std::string playerName;
                std::cout << "Enter player's name: ";
                std::cin >> playerName;

                int playerIndex = findPlayerIndex(players, MAX_PLAYERS, playerName);
                ans = playerIndex;
                if (playerIndex != -1) {
                    updateReceivingYards(players[playerIndex]);
                } else {
                    std::cout << "Player not found." << std::endl;
                }
                break;
            }
            case 7: {
                std::string playerName;
                std::cout << "Enter player's name: ";
                std::cin >> playerName;

                int playerIndex = findPlayerIndex(players, MAX_PLAYERS, playerName);
                ans = playerIndex;
                if (playerIndex != -1) {
                    updateRushingYards(players[playerIndex]);
                } else {
                    std::cout << "Player not found." << std::endl;
                }
                break;
            }
            case 99:
                std::cout << "Would you like to save data: (y,Y/n,N) ";
                char saveChoice;
                std::cin >> saveChoice;
                if (saveChoice == 'y' || saveChoice == 'Y') {
                    saveDataToFile(players);
                }
                break;
            default:
                std::cout << "Invalid choice. Please try again." << std::endl;
        }        
    } while (choice != 99);
    return 0;
}

void inputData(FootballPlayer players[], int index) {
    std::cout << "Enter player's name: ";
    std::cin >> players[index].playerName;
    std::cout << "Enter player's position: ";
    std::cin >> players[index].playerPosition;
    std::cout << "Enter number of touchdowns: ";
    std::cin >> players[index].touchdowns;
    std::cout << "Enter number of catches: ";
    std::cin >> players[index].catches;
    std::cout << "Enter number of passing yards: ";
    std::cin >> players[index].passingYards;
    std::cout << "Enter number of receiving yards: ";
    std::cin >> players[index].receivingYards;
    std::cout << "Enter number of rushing yards: ";
    std::cin >> players[index].rushingYards;
}

void outputData(FootballPlayer& player) {
    std::cout << "Name: " << player.playerName
              << " Position: " << player.playerPosition
              << " Touch Downs: " << player.touchdowns
              << " Number of Catches: " << player.catches
              << " Passing Yards: " << player.passingYards
              << " Receiving Yards: " << player.receivingYards
              << " Rushing Yards: " << player.rushingYards << std::endl;
}

void printEntireData(FootballPlayer players[]) {
    for (int i = 0; i < MAX_PLAYERS; ++i) {
        if (!players[i].playerName.empty()) {
            outputData(players[i]);
        }
    }
}

int findPlayerIndex(FootballPlayer players[], int size, const std::string& playerName) {



    for (int i = 0; i < size; ++i) {
        if (players[i].playerName == playerName) {
            return i;
        }
    }
    return -1; // Player not found
}

void updateTouchdowns(FootballPlayer& player) {
    std::cout << "Enter new number of touchdowns: ";
    std::cin >> player.touchdowns;
}

void updateCatches(FootballPlayer& player) {
    std::cout << "Enter new number of catches: ";
    std::cin >> player.catches;
}

void updatePassingYards(FootballPlayer& player) {
    std::cout << "Enter new number of passing yards: ";
    std::cin >> player.passingYards;
}

void updateReceivingYards(FootballPlayer& player) {
    std::cout << "Enter new number of receiving yards: ";
    std::cin >> player.receivingYards;
}

void updateRushingYards(FootballPlayer& player) {
    std::cout << "Enter new number of rushing yards: ";
    std::cin >> player.rushingYards;
}

void saveDataToFile(FootballPlayer players[]) {
    std::ofstream outputFile("Ch9_Ex7Output.txt");

    if (outputFile.is_open()) {
        for (int i = 0; i < MAX_PLAYERS; ++i) {
            
            if (players[i].playerName.empty()) {
                outputFile << players[i].playerName << " "
                           << players[i].playerPosition << " "
                           << players[i].touchdowns << " "
                           << players[i].catches << " "
                           << players[i].passingYards << " "
                           << players[i].receivingYards << " "
                           << players[i].rushingYards << std::endl;
            }

            else if (!players[i].playerName.empty()) {
                outputFile << players[i].playerName << " "
                           << players[i].playerPosition << " "
                           << players[i].touchdowns << " "
                           << players[i].catches << " "
                           << players[i].passingYards << " "
                           << players[i].receivingYards << " "
                           << players[i].rushingYards << std::endl;
            }
        }

        outputFile.close();
        std::cout << "Data saved to Ch9_Ex7Output.txt" << std::endl;
        
    } else {
        std::cerr << "Unable to open the file for saving." << std::endl;
    }
}