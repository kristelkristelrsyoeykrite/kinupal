## Instructions
Redo _Exercise 4_ so that the customer can select multiple items of a particular type. A sample output in this case is:


```
Welcome to Johnny's Resturant                                        
----Today's Menu----                                                 
1: Plain Egg       $1.45                                             
2: Bacon and Egg   $2.45                                             
3: Muffin          $0.99                                             
4: French Toast    $1.99                                             
5: Fruit Basket    $2.49                                             
6: Cereal          $0.69                                             
7: Coffee          $0.50                                             
8: Tea             $0.75                                             
                                                                     
You can make up to 8 different selections                            
Do you want to make selection Y/y (Yes), N/n (No): Y                 
                                                                     
Enter item number: 1                                                 
                                                                     
How many orders: 3                                                   
                                                                     
Select another item Y/y (Yes), N/n (No): Y                           
                                                                     
Enter item number: 8                                                 
                                                                     
How many orders: 1                                                   
                                                                     
Select another item Y/y (Yes), N/n (No): N                           
                                                                     
Welcome to Johnny's Resturant                                        
3 Plain Egg       $4.35                                              
1 Tea             $0.75                                              
  Tax             $0.26                                              
  Amount Due      $5.35  
```

