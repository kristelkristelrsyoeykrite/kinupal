// Including header files
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
using namespace std;
const int NO_OF_ITEMS = 8; // no of items
struct menuItemType // structure with two variable

{
    string menuItem;  // item name
    double menuPrice; // item price
};
// functions
void getData(ifstream& inFile, menuItemType mList[], int listSize);
void showMenu(menuItemType mList[], int listSize);
void printCheck(menuItemType mList[], int listSize,int cList[], int cListLength);
void makeSelection(int listSize,int cList[], int& cListLength);
bool isItemSelected(int cList[], int cListLength, int itemNo);
int main()  // given function
{
    menuItemType menuList[NO_OF_ITEMS];
    int choiceList[NO_OF_ITEMS];
    int choiceListLength;
    ifstream inFile;
    cout << fixed << showpoint << setprecision(2);
    inFile.open("Ch9_Ex5Data.txt");
    if (!inFile)
    {
        cout << "Cannot open the input file. Program Terminates!"<< endl;
        return 1;
    }
    getData(inFile, menuList, NO_OF_ITEMS);
    showMenu(menuList, NO_OF_ITEMS);
    makeSelection(NO_OF_ITEMS,choiceList, choiceListLength);
    printCheck(menuList, NO_OF_ITEMS,choiceList, choiceListLength);
    return 0;
}
void getData(ifstream& inFile, menuItemType mList[], int listSize) // given function
{
    char ch;
     for (int i = 0; i < listSize; i++){
        getline(inFile, mList[i].menuItem);
        inFile >> mList[i].menuPrice;
        inFile.get(ch);
    }
}
void showMenu(menuItemType mList[], int listSize)  // given function
{
    cout << "Welcome to Johnny's Resturant" << endl;
    cout << "----Today's Menu----" << endl;
    for (int i = 0; i < listSize; i++)
        cout << i+1 << ": " << left << setw(15) << mList[i].menuItem<< right << " $" << mList[i].menuPrice << endl;
    cout << endl;
}
void makeSelection(int listSize,int cList[], int& cListLength){ // makeSelection function
    // declaring variables
    char choice;
    int item_no;
    cListLength = 0; // initially cListLength is 0.
    for (int i = 0; i < listSize; ++i) // intially assigning 0 to every position in cList( initially no one is selected).
    {
        cList[i] = 0;
    }
    cout << "You can make upto 8 diffenrent selections" << endl;
    while(true){
        
        cout << "Do you want to make selection Y/y (Yes), N/n (No):";
        cin >> choice; // taking input from user
        if (choice == 'Y' || choice == 'y'){ // checking if choice is equal to "Y" or "y", if it is true than the if block will be executed
            cout << endl << "Enter item number: " ;
            cin >>  item_no ;
            cout << endl << "How many orders: ";
            cin >> cList[item_no - 1];
            cListLength++;
        }
        else if (choice =='N' || choice == 'n'){ // checking if choice is equal to "N" or "n" if it is true than the if block will be executed
            break; // break the loop
        }
        else{ // if the user enter other than the above options.
            cout << "Enter a valid choice..." << endl ;
        }
        cout << endl;
    }
}
void printCheck(menuItemType mList[], int listSize,int cList[], int cListLength){
     double salesTax;
   
    cout << endl;
    cout << "Welcome to Johnny's Resturant" << endl;
    double total = 0.0; // initially total amount is 0.0
    for (int i = 0; i < listSize; i++){ // iterate through each item.
        if (isItemSelected(cList,cListLength,i)){ // checking if the item is selected or not
            cout << cList[i] << " " << left << setw(15) << mList[i].menuItem<< right << " $" << mList[i].menuPrice *cList[i] << endl;
            total +=  mList[i].menuPrice * cList[i] ; // adding  mList[i].menuPrice * cList[i] value to total variable.
        }
    }
    salesTax = total * .05;
    cout << left << setw(15) << "Tax " << right << " $" 
         << salesTax << endl;
    total = total + salesTax;
    cout << left << setw(15) << "Amount Due " << right 
         << " $" << total << endl;
}

bool isItemSelected(int cList[], int cListLength, int itemNo){
    if (cList[itemNo] != 0 ){ // checking if the value at index itemNo in cList is 0 or not , if it not equal to 0 then return true
        return true;
    } // otherwise return false
    return false;
}