#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;


struct computerType
{
    string manufacturer;
    string modelType;
    string processorType;
    int ram;
    int hardDriveSize;
    int yearBuilt;
    double price;
};
void show( computerType m, computerType mt,computerType pt, computerType ram,computerType hds, computerType yb, computerType p);
int main() {
    computerType newcomp;
    string mf, mt,pt;
    int rm,hds,yb;
    double prc;

    newcomp.manufacturer=mf;
    newcomp.modelType=mt;
    newcomp.processorType=pt;
    newcomp.ram=rm;
    newcomp.hardDriveSize=hds;
    newcomp.yearBuilt=yb;
    newcomp.price=prc;

    cout<<"Enter the name of the manufacturer: ";
    getline(cin, mf);
    cout<<"Enter the model of the computer: ";
    getline(cin, mt);                                                          
    cout<<"Enter processor type: ";   
    getline(cin, pt);                                
    cout<<"Enter the size of RAM (in GB): "; 
     cin>>rm;
    cout<<"Enter the size of hard drive (in GB):  "; 
     cin>>hds;
    cout<<"Enter the year the computer was built:  "; 
     cin>>yb;
    cout<<"Enter the price: ";
    cin>>prc;    

    
    cout<<"Manufacturer: "<<mf<<endl;

    cout<<"Model: "<<mt<<endl;
    cout<<"Processor: "<<pt<<endl;
    cout<<"Ram: "<<rm<<endl;
    cout<<"Hard Drive Size: "<<hds<<endl;
    cout<<"Year Built: "<<yb<<endl;
    cout<<setw(7)<<"Price: $"<<fixed<<setprecision(2)<<prc<<endl;                                                        
 
    return 0;
}

  

