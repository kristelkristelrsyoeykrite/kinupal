//Include the required header files.

#include <iostream>

#include <fstream>

#include <iomanip>

#include <string>

 

//Use the standard namespace.

using namespace std;

 

//Define the structure studentType.

struct studentType

{

     //Declare the required variables.

     string studentFName;

     string studentLName;

     int testScore;

     char grade;

};

 

//Define the function readData() to read the

//data of the students from the input file.

void readData(ifstream &file_obj, struct studentType arr[])

{

     int curr_student = 0;

 

     while (!file_obj.eof())

     {

           file_obj >> arr[curr_student].studentFName;

           file_obj >> arr[curr_student].studentLName;

           file_obj >> arr[curr_student].testScore;

           curr_student++;

     }

}

 

//Define the function assignGrade()

//to assign the grades to the students.

void assignGrade(struct studentType arr[])

{

     for (int i = 0; i<20; i++)

     {

           int score = arr[i].testScore;

 

           if (score >= 90)

           {

                arr[i].grade = 'A';

           }

           else if (score >= 80)

           {

                arr[i].grade = 'B';

           }

           else if (score >= 70)

           {

                arr[i].grade = 'C';

           }

           else if (score >= 60)

           {

                arr[i].grade = 'D';

           }

           else

           {

                arr[i].grade = 'F';

           }

     }

}

 

//Define the function getHighestScore()

//to get the highest test score.

int getHighestScore(struct studentType arr[])

{

     int highestScore = -1;

     for (int i = 0; i < 20; i++)

     {

           if (arr[i].testScore > highestScore)

           {

                highestScore = arr[i].testScore;

           }

     }

     return highestScore;

}

 

//Define the function printHighest() to write the names

//of the students with the highest scores to the output file.

void printHighest(ofstream & outfile, struct studentType arr[], int highScore)

{

     outfile << "Students having the highest test score:" << endl;

 

     for (int i = 0; i < 20; i++)

     {

           if (arr[i].testScore == highScore)

           {

                outfile << left << arr[i].studentLName + ", " + arr[i].studentFName << endl;

           }

     }

}

 

//Define the function printData() to write

//the data of the students to the output file.

void printData(ofstream & outfile, struct studentType arr[])

{

     outfile << left << setw(30) << "Student Name";

     outfile << "\t";

     outfile << "Test Score";

     outfile << " Grade";

     outfile << endl;

     for (int i = 0; i < 20; i++)

     {

           outfile << left << setw(30) << arr[i].studentLName + ", " + arr[i].studentFName;

           outfile << right << setw(10) << arr[i].testScore;

           outfile << right << setw(6) << arr[i].grade;

           outfile << endl;

     }

     outfile << endl;

}

 

//Define the main() function.

int main()

{

     //Define an object of ifstream

     //class to open the input file.

     ifstream file_obj;

     file_obj.open("Ch9_Ex2Data.txt");

 

     ofstream out_file_obj;

     out_file_obj.open("Ch9_Ex2Out.txt");


     struct studentType arr[20];

 

     //Call the functions to perform the required operations.

     readData(file_obj, arr);

     assignGrade(arr);

     printData(out_file_obj, arr);

     int highScore = getHighestScore(arr);

     printHighest(out_file_obj, arr, highScore);

 

     //CLose the file objects.

     file_obj.close();

     out_file_obj.close();

 

     //Return from the main() function.

     return 0;

}