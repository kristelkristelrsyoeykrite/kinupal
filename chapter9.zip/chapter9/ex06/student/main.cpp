#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <stdio.h>
#include <bits/stdc++.h>
#include<cstdlib>
#include <iomanip>
using namespace std;
const int MAX_SIZE = 100;

//the required functions

void getFileName(ifstream &iFile);
void countWords(ifstream &iFile,ofstream &myfile);
void countChars(ifstream &iFile,int charCount[],double charPercentage[],int size);
void sortChars(int charCount[],double charPercentage[],char characters[],int size);
void printCount(ofstream &myfile,int charCount[],double charPercentage[],char characters[],int size);


int main()
{
ifstream iFile;

getFileName(iFile);



cout<<"Enter name of the ouput file: ";
string outfile;
cin>>outfile;

ofstream myfile;
myfile.open (outfile);

countWords(iFile,myfile);

int charCount[52]={0};
double charPercentage[52]={0};
  
char characters[52]={'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
  
countChars(iFile,charCount,charPercentage,52);
  
sortChars(charCount,charPercentage,characters,52);

printCount(myfile,charCount,charPercentage,characters,52);
}

void getFileName(ifstream &iFile)
{


// taking the input file name input from the user
cout<<"Please enter the input file name: ";
string infile;
cin>>infile;




//opening the file to read the contents
iFile.open(infile);
  
if (iFile.is_open())
{
cout<<"Successfully opened the file\n";
}

else
{
cout << "The input file does not exist\n";
  
exit(0);
}//if file not exist throwing error message


}

//counting number of words

void countWords(ifstream &iFile,ofstream &myfile)
{

string line;
int words=0;

while ( getline (iFile,line) )
{

string delimiter = " "; //splitting the line with spaces
size_t pos = 0;
string token;
while ((pos = line.find(delimiter)) != string::npos)
{
token = line.substr(0, pos);
words++;
line.erase(0, pos + delimiter.length());
}

token = line;
words++;
}
  
iFile.clear();
iFile.seekg(0, ios::beg);
//iFile.close();//closing the file
myfile<<"The total number of words are: "<<words<<"\n";
  

}

//counting number of characters and the percentage of each character

void countChars(ifstream &iFile,int charCount[],double charPercentage[],int size)
{

string line;
int total_char=0;
while ( getline (iFile,line) )
{

string delimiter = " "; //splitting the line with spaces
size_t pos = 0;
string token;
while ((pos = line.find(delimiter)) != string::npos)
{
token = line.substr(0, pos);
for(int i=0;i<token.length();i++)
{ 
char ch = (token[i]);
if(ch>='A' && ch<='Z')
{
    charCount[ch-65]++;//counting the capital chars
    total_char++;
}
if(ch>='a' && ch<='z')
{
    charCount[ch-97+26]++;//counting the small chars
    total_char++;
}

}

line.erase(0, pos + delimiter.length());
}

token = line;

for(int i=0;i<token.length();i++)
{
char ch = (token[i]);
if(ch>='A' && ch<='Z') //counting the capital chars
{
    charCount[ch-65]++;
    total_char++;
}
if(ch>='a' && ch<='z')//counting the small chars
{
    charCount[ch-97+26]++;
    total_char++;
}

}

}

for(int i=0;i<52;i++)
{
if(charCount[i]>0)
{
charPercentage[i]=(charCount[i]/(total_char*1.0))*100;
  
}
}
  
iFile.close();//closing the file
  
}

//sorting the characters by it's percentage of occurence

void sortChars(int charCount[],double charPercentage[],char characters[],int size)
{
  
for(int i=0;i<size;i++)
{
int minimum_index = i;
for (int j = i+1; j < size; j++)
{
if (charPercentage[minimum_index] > charPercentage[j]) //checking for the minimum value index
{
minimum_index = j;
}
}

//swapping the minimum value to the left side of the array
double temp=charPercentage[i];
charPercentage[i]=charPercentage[minimum_index];
charPercentage[minimum_index]=temp;
  
char c = characters[i];
characters[i] = characters[minimum_index];
characters[minimum_index] = c;
  
int t = charCount[i];
charCount[i] = charCount[minimum_index];
charCount[minimum_index] = t;
  
}
  
}

//printing in descending order

void printCount(ofstream &myfile,int charCount[],double charPercentage[],char characters[],int size)
{
 for (int i = 0; i < size; i++)
    {
        char currentChar = characters[i];

        // Check if the character is present in the file
        bool charPresent = (currentChar >= 'A' && currentChar <= 'Z') || (currentChar >= 'a' && currentChar <= 'z');

        if (charPresent)
        {
            myfile <<  currentChar << "\t" << charCount[i] << setw(4) <<"\t"  << setprecision(2) << fixed << charPercentage[i] << "%\n";
        }
        else
        {
            // Display 0% for characters not present in the file
            myfile << currentChar << "\t  0 \t  0.00%\n";
        }
    }
  
}

 