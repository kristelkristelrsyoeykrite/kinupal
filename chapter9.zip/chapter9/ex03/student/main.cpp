#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;

struct menuItemType{
    string menuItem;
    double menuPrice;

};

int main() {

    menuItemType food;

    food.menuItem = "Hamburger";
    cout<<food.menuItem<<endl;

    food.menuPrice = 56;
    cout<<"Php "<<food.menuPrice<<endl;
    


    return 0;
}