## Instructions
Define a `struct menuItemType` with two components: `menuItem` of type `string` and `menuPrice` of type `double`. 

